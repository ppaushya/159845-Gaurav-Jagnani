package org.cap.demo;

import java.io.Serializable;
import java.time.LocalDate;

public class Product implements Serializable{

	private int productID;
	private double productPrice;
	private String productName;
	private int quantity;
	private LocalDate productExpiryDate;
	
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public LocalDate getProductExpiryDate() {
		return productExpiryDate;
	}
	public void setProductExpiryDate(LocalDate productExpiryDate) {
		this.productExpiryDate = productExpiryDate;
	}
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productPrice=" + productPrice + ", productName=" + productName
				+ ", quantity=" + quantity + ", productExpiryDate=" + productExpiryDate + "]";
	}
	public Product(int productID, double productPrice, String productName, int quantity, LocalDate productExpiryDate) {
		super();
		this.productID = productID;
		this.productPrice = productPrice;
		this.productName = productName;
		this.quantity = quantity;
		this.productExpiryDate = productExpiryDate;
	}
	public Product() {
		super();
	}
}
