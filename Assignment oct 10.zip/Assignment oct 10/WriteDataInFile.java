package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;


public class WriteDataInFile {

	public static void main(String[] args) throws FileNotFoundException {

		File file=new File("D:\\Demo\\writeFile.txt");
		
		String greetings="Good Noon!";
		
		try (FileWriter writer=new FileWriter(file)){
			
			/*char[] ch=greetings.toCharArray();
			
			for(char c:ch)*/
				writer.write(greetings);
			
		} catch (IOException e) {

			e.printStackTrace();
		}
		
		
		
	}

}
