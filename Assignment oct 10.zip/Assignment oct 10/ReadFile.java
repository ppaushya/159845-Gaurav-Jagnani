package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {		

		
		File file = new File("D:\\Demo\\myfile.txt");
		int c=0,i=0;
		
		try(FileReader reader = new FileReader(file)) {
			while((c = reader.read())!=-1) {
				i++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		char[] str=new char[i];
		i=0;
		try(FileReader reader = new FileReader(file)) {
			while((c = reader.read())!=-1) {
				str[i] = (char)c;
				i++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		c=str.length;
		c--;
		for(i=c;i>=0;i--)
			System.out.print(str[i]);
	}
}
