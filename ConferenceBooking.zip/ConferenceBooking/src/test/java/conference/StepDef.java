package conference;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webdriver;
	private WebElement webelement;
	private String message;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\gjagnani\\Desktop\\chromedriver.exe");
		
		webdriver=new ChromeDriver();
	}
	
	
	@Given("^Open Conference Registartion page$")
	public void open_Conference_Registartion_page() throws Throwable {
	    webdriver.get("file:///D:/Users/gjagnani/Desktop/Practicals/Conferencebooking/ConferenceRegistartion.html");
	}

	@When("^correct title$")
	public void correct_title() throws Throwable {
	    webelement=webdriver.findElement(By.xpath("/html/body/h2"));
	    
	    if(!webelement.getText().equals("Conference Registration")) {
	    	System.out.println("FALSE");
	    	webdriver.quit();
	    }
	    System.out.println("TRUE");
	}

	@When("^correct heading$")
	public void correct_heading() throws Throwable {
		webelement=webdriver.findElement(By.xpath("/html/body/h4"));
	    
	    if(!webelement.getText().equals("Step 1: Personal Details")) {
	    	System.out.println("FALSE");
	    	webdriver.quit();
	    }
	    System.out.println("TRUE");
	}

	@Then("^enter registration details$")
	public void enter_registration_details() throws Throwable {
		webdriver.quit();
	}

	@Given("^valid registration page$")
	public void valid_registration_page() throws Throwable {
		webdriver.get("file:///D:/Users/gjagnani/Desktop/Practicals/Conferencebooking/ConferenceRegistartion.html");
	}

	@Given("^enter valid details$")
	public void enter_valid_details() throws Throwable {
	    
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		webelement.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Please fill the First Name");
		webdriver.switchTo().alert().accept();
		webelement = webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]"));
		System.out.println(webelement.isDisplayed());
		webelement.sendKeys("Tom");
		
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		webelement.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Please fill the Last Name");
		webdriver.switchTo().alert().accept();
		webelement = webdriver.findElement(By.xpath("//*[@id=\"txtLastName\"]"));
		System.out.println(webelement.isDisplayed());
		webelement.sendKeys("Jerry");
		
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		webelement.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Please fill the Email");
		webdriver.switchTo().alert().accept();
		webelement = webdriver.findElement(By.xpath("//*[@id=\"txtEmail\"]"));
		System.out.println(webelement.isDisplayed());
		webelement.sendKeys("tom@gmail.com");
		
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		webelement.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Please fill the Contact No.");
		webdriver.switchTo().alert().accept();
		webelement = webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]"));
		System.out.println(webelement.isDisplayed());
		webelement.sendKeys("5854789654");
		
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		webelement.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Please enter valid Contact no.");
		webdriver.switchTo().alert().accept();
		webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).clear();
		webelement = webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]"));
		System.out.println(webelement.isDisplayed());		
		webelement.sendKeys("7854789654");
		
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		webelement.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Please fill the Number of people attending");
		webdriver.switchTo().alert().accept();
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select/option[3]"));
		System.out.println(webelement.isDisplayed());
		webelement.click();
		
		webdriver.findElement(By.xpath("//*[@id=\"txtAddress1\"]")).sendKeys("Vesu");
		webdriver.findElement(By.xpath("//*[@id=\"txtAddress2\"]")).sendKeys("Surat");
		
		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select/option[3]")).click();
		
		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select/option[3]")).click();
		
		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input")).click();
		
		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input")).click();
		
	}

	@When("^click next$")
	public void click_next() throws Throwable {
	    
	}

	@Then("^navigate to Payment Details$")
	public void navigate_to_Payment_Details() throws Throwable {
	    
		webelement = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		webelement.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Personal details are validated.");
		webdriver.switchTo().alert().accept();
		
		message = webdriver.getCurrentUrl();
		assertEquals("file:///D:/Users/gjagnani/Desktop/Practicals/Conferencebooking/PaymentDetails.html", message);
		
		webdriver.quit();
	}

	@Given("^Payment Details page$")
	public void payment_Details_page() throws Throwable {
	    
		webdriver.get("file:///D:/Users/gjagnani/Desktop/Practicals/Conferencebooking/PaymentDetails.html"); 
		
	}

	@Given("^valid details$")
	public void valid_details() throws Throwable {
	    
		webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("Tom");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtDebit\"]")).sendKeys("478547854785");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtCvv\"]")).sendKeys("745");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtMonth\"]")).sendKeys("05");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtYear\"]")).sendKeys("2019");
		
	}

	@When("^click Make Payment$")
	public void click_Make_Payment() throws Throwable {
	    
		webelement = webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		webelement.click();
		
	}

	@Then("^success$")
	public void success() throws Throwable {
	    
		message = webdriver.switchTo().alert().getText();
		assertEquals(message,"Conference Room Booking successfully done!!!");
		webdriver.switchTo().alert().accept();
		
		webdriver.quit();
	}
}