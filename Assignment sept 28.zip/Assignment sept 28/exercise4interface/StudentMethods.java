package exercise4interface;

public interface StudentMethods {
	
	public void displayGrade();
	public void displayAttendence();
}
