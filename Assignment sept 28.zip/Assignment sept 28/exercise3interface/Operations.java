package exercise3interface;

public interface Operations {
	
	public float division(float number1,float number2);
	public int modulo(int divident,int divisor);
}
