package exercise2constants;

public class MainClass {

	public static void main(String[] args) {
		
		System.out.println("Days of weeks and its values: ");
		System.out.println("SUN "+Constants.SUN);
		System.out.println("MON "+Constants.MON);
		System.out.println("TUE "+Constants.TUE);
		System.out.println("WED "+Constants.WED);
		System.out.println("THU "+Constants.THU);
		System.out.println("FRI "+Constants.FRI);
		System.out.println("SAT "+Constants.SAT);
	}

}
