package Balance;

public class Account {

	public void displayBalance()
	{
		System.out.println("Balance Package --> Account Class --> displayBalance Method");
	}
}