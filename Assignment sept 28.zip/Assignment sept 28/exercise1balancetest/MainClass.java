package exercise1balancetest;

import exercise1balance.Account;

public class MainClass {

	public static void main(String[] args) {
		Account ac = new Account(100,100,50000);
		ac.displayBalance();
	}

}
