package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.LoginPojo;
import org.cap.model.RegisterPojo;
import org.cap.service.ILoginService;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@Autowired
	private ILoginService loginService;
	
	@Autowired
	private IRegisterService registerService;

	@RequestMapping("/")
	public ModelAndView getIndexPage() {
		
		return new ModelAndView("index", "login", new LoginPojo());
	}
	
	@RequestMapping("/validateLogin")
	public String validateLogin(ModelMap modelMap, @ModelAttribute("login") LoginPojo loginPojo) {
		
		List<RegisterPojo> registerPojos=registerService.listAllRegisterations();
		
		if(loginService.isValidLogin(loginPojo)) {
			
			modelMap.addAttribute("butLabel","Register");
			modelMap.addAttribute("register", new RegisterPojo());
			modelMap.addAttribute("registerPojos",registerPojos);
			modelMap.addAttribute("qualification", getQualifications());
			return "register";
		}
		return"redirect:/";
	}
	
	private List<String> getQualifications(){
		List<String> list=new ArrayList<>();
		
		list.add("MBA");
		list.add("BE");
		list.add("B.Tech");
		list.add("BCom");
		list.add("BSc");
		
		return list;
	}
	
}