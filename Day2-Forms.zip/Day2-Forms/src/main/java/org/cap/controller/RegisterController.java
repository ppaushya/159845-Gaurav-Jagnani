package org.cap.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.validation.Valid;

import org.cap.model.RegisterPojo;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class RegisterController {

	/*@RequestMapping(value="/registerForm",method=RequestMethod.POST)
	@PostMapping("/register")
	public String registerDetails(@ModelAttribute("register")RegisterPojo registerPojo) {
		return "success";
	}*/
	
	private RegisterPojo registerPojo;
	
	@Autowired
	private IRegisterService registerService;
	private boolean flag;
	
	/*@RequestMapping(value="/register", method=RequestMethod.POST)
	public String registerDetails(ModelMap modelMap, @Valid @ModelAttribute("register") RegisterPojo registerPojo,
			BindingResult result) {
		if(result.hasErrors()) {
			return "register";
		}
		
		registerService.registerCustomer(registerPojo);
		return "redirect:register";
	}*/

	@RequestMapping("/register")
	public String showRegistrationPage(ModelMap modelMap) {
		List<RegisterPojo> registerPojos= registerService.listAllRegisterations();
		String butLabel="Update";
		
		if(!flag) {
			butLabel="Register";
			modelMap.addAttribute("register", new RegisterPojo());
		}
		else
			modelMap.addAttribute("register",registerPojo);
		
		modelMap.addAttribute("butLabel",butLabel);
		modelMap.addAttribute("registers", registerPojos);
		modelMap.addAttribute("flag", flag);
		//flag=false;
		return "register";
	}
	

	//@RequestMapping(value="/registerForm",method=RequestMethod.POST)
	@PostMapping("/registerForm")
	public String registerDetails(
			@Valid @ModelAttribute("register")RegisterPojo registerPojo,
				BindingResult result) {
		
		if(result.hasErrors())
			return "register";
		 
		if(!flag) {
			registerService.updateCustomer(registerPojo);
		}
		else {
			registerService.registerCustomer(registerPojo);
			flag=false;
		}
		return "redirect:/register";
	}
	
	
	@RequestMapping("/delete/{registrationId}")
	public String deleteEntry(@PathVariable("registrationId") Integer registrationId) {
	
		registerService.deleteEntry(registrationId);
		
		return "redirect:/register";
	}
	
	@RequestMapping("/edit/{registrationId}")
	public String editEntry(@PathVariable("registrationId") Integer registrationId) {
		
		flag=true;
		registerPojo=registerService.findCustomer(registrationId);
		registerService.updateCustomer(registerPojo);
		return "redirect:/register";
	}
	
}