package org.cap.service;

import java.util.List;

import org.cap.dao.IRegisterDao;
import org.cap.model.RegisterPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("registerService")
public class RegisterService implements IRegisterService{


	@Autowired
	private IRegisterDao registerDao;

	@Override
	public boolean registerCustomer(RegisterPojo registerPojo) {

		return registerDao.registerCustomer(registerPojo);
	}
	
	@Override
	public List<RegisterPojo> listAllRegisterations() {
		
		return registerDao.listAllRegisterations();
	}

	@Override
	public void deleteEntry(int registrationId) {
		registerDao.deleteCustomer(registrationId);
		
	}

	@Override
	public RegisterPojo findCustomer(int registrationId) {
		
		return registerDao.findCustomer(registrationId);
	}

	@Override
	public void updateCustomer(RegisterPojo registerPojo) {
		
		registerDao.updateCustomer(registerPojo);
		
	}
}