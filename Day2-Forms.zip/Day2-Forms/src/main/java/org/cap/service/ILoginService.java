package org.cap.service;

import java.util.List;

import org.cap.model.LoginPojo;
import org.cap.model.RegisterPojo;

public interface ILoginService {

	public boolean isValidLogin(LoginPojo loginPojo);
	
}
