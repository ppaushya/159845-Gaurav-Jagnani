package org.cap.service;

import java.util.List;

import org.cap.model.RegisterPojo;

public interface IRegisterService {

	public boolean registerCustomer(RegisterPojo registerPojo);
	public List<RegisterPojo> listAllRegisterations();
	public void deleteEntry(int registrationId) ;
	public RegisterPojo findCustomer(int registrationId);
	public void updateCustomer(RegisterPojo registerPojo);
	
}
