package org.cap.service;

import java.util.List;

import org.cap.dao.ILoginDao;
import org.cap.model.LoginPojo;
import org.cap.model.RegisterPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginService implements ILoginService{
	
	@Autowired
	private ILoginDao loginDao;

	@Override
	public boolean isValidLogin(LoginPojo loginPojo) {
		
		/*if(loginPojo.getUserName().equals("tom"))
			if(loginPojo.getUserPassword().equals("tom123"))
			return true;
		return false;*/
		
		return loginDao.isValidLogin(loginPojo);
	}
}
