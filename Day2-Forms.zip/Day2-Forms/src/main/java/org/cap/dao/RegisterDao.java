package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.RegisterPojo;
import org.springframework.stereotype.Repository;

@Repository("registerDao")
@Transactional
public class RegisterDao implements IRegisterDao{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public boolean registerCustomer(RegisterPojo registerPojo) {
		
		em.persist(registerPojo);
		
		return true;
	}
	
	@Override
	public List<RegisterPojo> listAllRegisterations() {
		

		List<RegisterPojo> registerPojos= em.createQuery("from RegisterPojo").getResultList();
		
		return registerPojos;
	}

	@Override
	public void deleteCustomer(int registrationId) {
		
		RegisterPojo registerPojo= em.find(RegisterPojo.class, registrationId);
		
		em.remove(registerPojo);
		
	}

	@Override
	public RegisterPojo findCustomer(int registrationId) {
		
		RegisterPojo registerPojo= em.find(RegisterPojo.class, registrationId);
		
		return registerPojo;
	}

	@Override
	public void updateCustomer(RegisterPojo registerPojo) {
		
		em.merge(registerPojo);
		
	}
}