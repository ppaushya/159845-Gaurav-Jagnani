package org.cap.dao;

import java.util.List;

import org.cap.model.RegisterPojo;

public interface IRegisterDao {

	public boolean registerCustomer(RegisterPojo registerPojo);
	public List<RegisterPojo> listAllRegisterations();
	public void deleteCustomer(int registrationId) ;
	public RegisterPojo findCustomer(int registrationId);
	public void updateCustomer(RegisterPojo registerPojo);
	
}
