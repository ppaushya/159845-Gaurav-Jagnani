package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.LoginPojo;
import org.cap.model.RegisterPojo;
import org.springframework.stereotype.Repository;

@Repository("loginDao")
@Transactional
public class LoginDao implements ILoginDao{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public boolean isValidLogin(LoginPojo loginPojo) {
		
		String sql = "from Customer where userName=:emailId and userPassword=:customerPassword";
		Query query=em.createQuery(sql);
		query.setParameter("user_name", loginPojo.getUserName());
		query.setParameter("password", loginPojo.getUserPassword());
		
		List<LoginPojo> list=query.getResultList();
		
		if(!list.isEmpty()) {
			return true;
		}
		
		return false;
	}

}