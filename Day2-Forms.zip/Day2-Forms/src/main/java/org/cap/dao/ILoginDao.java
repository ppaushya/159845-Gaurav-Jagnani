package org.cap.dao;

import java.util.List;

import org.cap.model.LoginPojo;
import org.cap.model.RegisterPojo;

public interface ILoginDao {

	public boolean isValidLogin(LoginPojo loginPojo);
	
}
