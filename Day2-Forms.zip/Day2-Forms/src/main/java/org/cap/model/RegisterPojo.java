package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="customer_register")
public class RegisterPojo {
	
	@Id
	@GeneratedValue
	private int registrationId;

	@NotEmpty(message="* Please Enter First Name!")
	private String firstName;
	
	@NotEmpty(message="* Please Enter Last Name!")
	private String lastName;
	
	private String address;
	private String city;
	private String gender;
	private String qualification;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="dd-MMM-yyyy")
	@Past(message="* We hope you have taken birth")
	private Date dateOfBirth;
	private String password;
	
	@Transient
	private String confirmPassword;
	
	@Range(min=1000, max=5000, message="* Registration Fees must be in range of 1000 to 5000")
	private double registrationFees;
	
	@NotEmpty(message="* Enter Email Id")
	@Email(message="* Enter Proper Email Id")
	private String emailId;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public double getRegistrationFees() {
		return registrationFees;
	}
	public void setRegistrationFees(double registrationFees) {
		this.registrationFees = registrationFees;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	@Override
	public String toString() {
		return "RegisterPojo [firstName=" + firstName + ", lastname=" + lastName + ", address=" + address + ", city="
				+ city + ", gender=" + gender + ", qualification=" + qualification + ", dateOfBirth=" + dateOfBirth
				+ ", password=" + password + "]";
	}
	public RegisterPojo(String firstName, String lastName, String address, String city, String gender,
			String qualification, Date dateOfBirth, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
	}
	public RegisterPojo() {
		super();
	}
}
